import React from 'react'

/**
* @author
* @function Loder
**/

const Loder = (props) => {
  return(
    <div className="loader"></div>
   )
  }


export default Loder